#ifndef SAFETOPWIDGET_H
#define SAFETOPWIDGET_H

#include <QWidget>

class SafeTopWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SafeTopWidget(QWidget *parent = 0);

signals:

public slots:

};

#endif // SAFETOPWIDGET_H
