#include "safetopwidget.h"

SafeTopWidget::SafeTopWidget(QWidget *parent) :
    QWidget(parent)
{
}
