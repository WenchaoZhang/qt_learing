#ifndef SAFEBOTTOMWIDGET_H
#define SAFEBOTTOMWIDGET_H

#include <QWidget>

class SafeBottomWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SafeBottomWidget(QWidget *parent = 0);

signals:

public slots:

};

#endif // SAFEBOTTOMWIDGET_H
