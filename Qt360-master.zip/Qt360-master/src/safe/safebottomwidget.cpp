#include "safebottomwidget.h"

SafeBottomWidget::SafeBottomWidget(QWidget *parent) :
    QWidget(parent)
{
}
