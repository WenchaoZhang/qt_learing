#ifndef MAINEXAMINEWIDGET_H
#define MAINEXAMINEWIDGET_H

#include <QWidget>
#include "../../commom/basestylewidget.h"

class MainExamineWidget : public BaseStyleWidget
{
    Q_OBJECT
public:
    explicit MainExamineWidget(QWidget *parent = 0);

signals:

public slots:

};

#endif // MAINEXAMINEWIDGET_H
