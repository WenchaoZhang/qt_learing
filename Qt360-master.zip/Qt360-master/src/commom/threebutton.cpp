#include "threebutton.h"

ThreeButton::ThreeButton(QWidget *parent) :
    QWidget(parent)
{
}
