#ifndef SPEEDOUTBUTTONWIDGET_H
#define SPEEDOUTBUTTONWIDGET_H

#include <QWidget>

class SpeedOutButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SpeedOutButtonWidget(QWidget *parent = 0);

signals:

public slots:

};

#endif // SPEEDOUTBUTTONWIDGET_H
