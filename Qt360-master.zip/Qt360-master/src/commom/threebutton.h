#ifndef THREEBUTTON_H
#define THREEBUTTON_H

#include <QWidget>

class ThreeButton : public QWidget
{
    Q_OBJECT
public:
    explicit ThreeButton(QWidget *parent = 0);

signals:

public slots:

};

#endif // THREEBUTTON_H
