#include "speedoutbuttonwidget.h"

SpeedOutButtonWidget::SpeedOutButtonWidget(QWidget *parent) :
    QWidget(parent)
{
}
